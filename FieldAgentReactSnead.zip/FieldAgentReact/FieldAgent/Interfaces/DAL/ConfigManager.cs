﻿using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FieldAgent.Core.Interfaces.DAL
{
    class ConfigManager
    {/*
        if (string.IsNullOrEmpty(_connectionString))
        {
        var builder = new ConfigurationBuilder();

        //builder.SetBasePath(Directory.GetCurrentDirectory());
        //builder.AddJsonFile("secrets.json", false, true);
        builder.AddUserSecrets("ConnectionStringsFieldAgent");
        var config = builder.Build();

        _connectionString = config["ConnectionStrings:FieldAgent"];
        }
    */
    }
}
