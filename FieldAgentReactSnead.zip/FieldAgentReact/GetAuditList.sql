create procedure GetAuditList(
    @securityClearanceId as int, @agencyId as int 
)
as 
begin 
select 
aga.BadgeId, CONCAT(a.FirstName, a.LastName) FullName, a.DateOfBirth, aga.ActivationDate, aga.DeactivationDate
from AgencyAgent aga
inner join Agent a on a.AgentId = aga.AgentId
where aga.AgencyId = @agencyId AND aga.SecurityClearanceId = @securityClearanceId
end
