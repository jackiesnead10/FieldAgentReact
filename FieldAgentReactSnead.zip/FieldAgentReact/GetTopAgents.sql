Create procedure GetTopAgents
-- Get a list of tables and views in the current database
as 
BEGIN select top(3) a.AgentId, CONCAT(a.FirstName, a.LastName) FullName, a.DateOfBirth, Count(mi.ActualEndDate) CompletedMissions from Agent a
Inner Join MissionAgent m on m.AgentId = a.AgentId
Inner Join Mission mi on mi.MissionId = m.MissionId
where mi.ActualEndDate is not null
group by a.AgentId, a.FirstName, a.LastName, a.DateOfBirth
order by CompletedMissions DESC
End
